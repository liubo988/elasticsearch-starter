package com.ygw.es.client.operations;

import java.util.List;
import java.util.Map;

import org.elasticsearch.action.ActionListener;
import org.elasticsearch.action.bulk.BulkResponse;
import org.elasticsearch.action.delete.DeleteRequest;
import org.elasticsearch.action.delete.DeleteResponse;
import org.elasticsearch.action.get.GetRequest;
import org.elasticsearch.action.get.GetResponse;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.action.update.UpdateRequest;
import org.elasticsearch.action.update.UpdateResponse;

import com.ygw.es.core.RestClientAsyncCallback;
import com.ygw.es.core.RestClientCallback;

/**
 * <p>Title: DocumentOperations </p>
 * <p>Description: 文档操作接口定义</p>
 * <p>Copyright (c) 2020 </p>
 * <p>Company: 上海阳光喔科技有限公司</p>
 *
 * @author bobo
 * @version 1.0
 * <p>修改人：bobo</p>
 * <p>修改时间：2020年5月7日 下午12:03:49</p>
 * <p>修改备注：</p>
 * @date 2020年5月7日 下午12:03:49
 */
public interface DocumentOperations {

    <T> T execute(RestClientCallback<T> callback);

    void asyncExecute(RestClientAsyncCallback callback);

    IndexResponse persist(IndexRequest request);

    /**
     * insertList: 批量插入数据集合
     *
     * @param indexName 索引名称
     * @param documents 数据集合
     * @return
     */
    BulkResponse insertList(String indexName, List documents);

    /**
     * insert：插入文档对象
     *
     * @param indexName 索引名称
     * @param document  文档对象
     * @return
     * @throws
     * @author bobo
     * @date 2020年5月8日 下午5:11:18
     */
    IndexResponse insert(String indexName, Object document);

    void persist(IndexRequest request, ActionListener<IndexResponse> listener);

    UpdateResponse update(UpdateRequest request);

    void update(UpdateRequest request, ActionListener<UpdateResponse> listener);

    DeleteResponse delete(DeleteRequest request);

    void delete(DeleteRequest request, ActionListener<DeleteResponse> listener);

    Map<String, Object> get(GetRequest request);

    void get(GetRequest request, ActionListener<GetResponse> listener);

    /**
     * findById：根据文档id获取对象
     *
     * @param indexName  索引名称
     * @param documentId 文档id
     * @param clazz      类的类型
     * @return
     * @throws
     * @author bobo
     * @date 2020年5月8日 下午5:33:43
     */
    <T, K, V> T findById(String indexName, String documentId, Class<?> clazz);

    /**
     * 更新对象（如果对象属性为空,空属性也会更新）
     * @param indexName 索引名称
     * @param documents 文档对象
     * @return
     */
    UpdateResponse update(String indexName, Object documents);

    /**
     * 更新对象（只更新不为空的属性）
     * @param indexName 索引名称
     * @param document 文档对象
     * @return
     */
    public UpdateResponse updateSelectiveById(String indexName, Object document);

    /**
     * deleteById：根据文档id获取对象
     *
     * @param indexName  索引名称
     * @param documentId 文档id
     * @param clazz      类的类型
     * @return Boolean
     * @throws
     * @author bobo
     * @date 2020年5月8日 下午5:33:43
     */
    DeleteResponse deleteById(String indexName, String documentId);

    /**
     * insertAsync：异步插入文档
     *
     * @param indexName 索引名称
     * @param document  文档数据
     * @param listener  监听器
     * @throws
     * @author bobo
     * @date 2020年5月13日 上午9:50:26
     */
    void insertAsync(String indexName, Object document, ActionListener<IndexResponse> listener);

    /**
     * 更新默认修改时间
     *
     * @param document 对象
     */
    void setDefaultUpdateTime(Object document);
}

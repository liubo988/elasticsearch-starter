package com.ygw.es.connection;

import org.apache.commons.pool2.impl.GenericObjectPoolConfig;

/**
 * 
 * 		
 * <p>Title: RestClientPoolConfig </p>
 * <p>Description: 连接池配置（默认属性）继承GenericObjectPoolConfig</p>
 * <p>Copyright (c) 2020 </p>
 * <p>Company: 上海阳光喔科技有限公司</p>
 * @author bobo	
 * @date 2020年5月7日 下午12:01:08	
 * @version 1.0
 * <p>修改人：bobo</p>
 * <p>修改时间：2020年5月7日 下午12:01:08</p>
 * <p>修改备注：</p>
 */
public class RestClientPoolConfig extends GenericObjectPoolConfig {

	public RestClientPoolConfig() {
		/**
		 * 默认false，在evictor线程里头，当evictionPolicy.evict方法返回false时，而且testWhileIdle为true的时候则检测是否有效，如果无效则移除
		 */
		setTestWhileIdle(true);
		/**
		 * 连接空闲的最小时间，达到此值后空闲连接将可能会被移除。默认为1000L 60L 30L
		 */
		setMinEvictableIdleTimeMillis(60000);
		/**
		 * 空闲链接检测线程检测的周期，毫秒数。如果为负值，表示不运行检测线程。默认为-1.
		 */
		setTimeBetweenEvictionRunsMillis(30000);
		/**
		 * 在每次空闲连接回收器线程(如果有)运行时检查的连接数量，默认为3
		 */
		setNumTestsPerEvictionRun(-1);
	}
}

package com.ygw.es.core;

import java.io.IOException;

import org.elasticsearch.client.RestHighLevelClient;

/**
 * 		
 * <p>Title: RestClientCallback </p>
 * <p>Description: client同步回调</p>
 * <p>Copyright (c) 2020 </p>
 * <p>Company: 上海阳光喔科技有限公司</p>
 * @author bobo	
 * @date 2020年5月7日 下午12:05:16	
 * @version 1.0
 * @param <T>
 * <p>修改人：bobo</p>
 * <p>修改时间：2020年5月7日 下午12:05:16</p>
 * <p>修改备注：</p>
 */
public interface RestClientCallback<T> {

	T doInRestClient(RestHighLevelClient client) throws IOException;
}

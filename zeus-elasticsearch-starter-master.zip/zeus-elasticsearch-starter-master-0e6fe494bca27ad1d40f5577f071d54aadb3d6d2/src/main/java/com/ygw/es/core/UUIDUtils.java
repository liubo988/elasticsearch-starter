package com.ygw.es.core;

import java.util.UUID;

/**
 * Title : UUIDUtils
 * Description: 类描述
 * Copyright (c) 2020
 * Company: 上海阳光喔科技有限公司
 * <p>
 * 修改人: bobo
 * 修改时间: 2020年07月08日 15:15
 * 修改备注:
 *
 * @author bobo
 * @version 1.0
 * @date 2020年07月08日 15:15
 */
public class UUIDUtils {
    public UUIDUtils() {
    }

    public static String getUUID() {
        return UUID.randomUUID().toString();
    }

    public static String getUUID32Bit() {
        return UUID.randomUUID().toString().replace("-", "");
    }
}

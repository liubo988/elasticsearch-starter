package com.ygw.es.core;

import java.io.IOException;

import org.elasticsearch.client.RestHighLevelClient;

/**
 * 		
 * <p>Title: RestClientAsyncCallback </p>
 * <p>Description: client异步回调</p>
 * <p>Copyright (c) 2020 </p>
 * <p>Company: 上海阳光喔科技有限公司</p>
 * @author bobo	
 * @date 2020年5月7日 下午12:05:05	
 * @version 1.0
 * <p>修改人：bobo</p>
 * <p>修改时间：2020年5月7日 下午12:05:05</p>
 * <p>修改备注：</p>
 */
public interface RestClientAsyncCallback {

	void doInRestAsyncClient(RestHighLevelClient client) throws IOException;
}

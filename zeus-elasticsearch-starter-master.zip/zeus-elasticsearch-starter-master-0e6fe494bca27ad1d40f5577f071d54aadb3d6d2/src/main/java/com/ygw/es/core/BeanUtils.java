package com.ygw.es.core;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Type;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Map;

/**
 * <p>Title: BeanUtils </p>
 * <p>Description: bean工具包(bean->map转换)</p>
 * <p>Copyright (c) 2020 </p>
 * <p>Company: 上海阳光喔科技有限公司</p>
 *
 * @author bobo
 * @version 1.0
 * <p>修改人：bobo</p>
 * <p>修改时间：2020年5月8日 下午5:27:29</p>
 * <p>修改备注：</p>
 * @date 2020年5月8日 下午5:27:29
 */
public class BeanUtils {
    /**
     * map2Bean：map对象转化为bean对象
     *
     * @param mp      map对象
     * @param beanCls bean对象
     * @return
     * @throws Exception
     * @throws IllegalArgumentException
     * @throws InvocationTargetException
     * @throws
     * @author bobo
     * @date 2020年5月8日 下午5:30:15
     */
    public static <T, K, V> T map2Bean(Map<K, V> mp, Class<T> beanCls) {
        T t = null;
        try {
            BeanInfo beanInfo = Introspector.getBeanInfo(beanCls);
            PropertyDescriptor[] propertyDescriptors = beanInfo.getPropertyDescriptors();

            t = beanCls.newInstance();

            for (PropertyDescriptor property : propertyDescriptors) {
                String key = property.getName();

                if (mp.containsKey(key)) {
                    Object value = mp.get(key);
                    // Java中提供了用来访问某个属性getter/setter方法
                    Method setter = property.getWriteMethod();
                    Type[] paramTypes = setter.getGenericParameterTypes();
                    for (Type type : paramTypes) {
                        if (value != null && type.toString().equals("class java.util.Date")) {//判断是否是日期类型
                            value = parseToDate((String) value);
                        }
                    }
                    //执行方法反射
                    setter.invoke(t, value);
                }
            }

        } catch (IntrospectionException e) {

            e.printStackTrace();
        } catch (Exception e) {

            e.printStackTrace();
        }
        return t;
    }

    /**
     * bean2Map：bean对象转化为map对象
     *
     * @param bean
     * @param mp
     * @return
     * @throws Exception
     * @throws IllegalAccessException
     * @throws
     * @author bobo
     * @date 2020年5月8日 下午5:31:01
     */
    public static <T, K, V> Map<String, Object> bean2Map(T bean, Map<String, Object> mp) {

        if (bean == null) {
            return null;
        }

        try {
            BeanInfo beanInfo = Introspector.getBeanInfo(bean.getClass());
            PropertyDescriptor[] propertyDescriptors = beanInfo.getPropertyDescriptors();

            for (PropertyDescriptor property : propertyDescriptors) {
                String key = property.getName();

                if (!key.equals("class")) {
                    // Java中提供了用来访问某个属性的getter/setter方法
                    Method getter = property.getReadMethod();
                    Object value;
                    value = getter.invoke(bean);
                    mp.put(key, value);
                }

            }

        } catch (IntrospectionException e) {
            e.printStackTrace();
        } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();

        }
        return mp;
    }

    public static Date parseToDate(String date) {
        SimpleDateFormat sdf = new SimpleDateFormat("MMM d, yyyy K:m:s a", Locale.ENGLISH);
        Date d2 = null;
        try {
            //把Jul 8, 2020 12:00:00 AM格式转换为常规的Date格式
            d2 = sdf.parse(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return d2;
    }
}

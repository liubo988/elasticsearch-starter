package com.ygw.es.core;

import java.util.UUID;

/**
 * 		
 * <p>Title: UUIDGenerator </p>
 * <p>Description: UUID操作</p>
 * <p>Copyright (c) 2018 </p>
 * <p>Company: 上海阳光喔教育科技有限公司</p>
 * @author lb	
 * @date 2018年5月8日 下午12:16:53	
 * @version 1.0
 * <p>修改人：Administrator</p>
 * <p>修改时间：2018年5月8日 下午12:16:53</p>
 * <p>修改备注：</p>
 */
public abstract class UUIDGenerator {
	public static String getUUID() {
		return UUID.randomUUID().toString();
	}

	public static String getUUID32Bit() {
		return UUID.randomUUID().toString().replace("-", "");
	}
}
package com.ygw.es.vo;

import lombok.Data;

/**
 * 		
 * <p>Title: RequestLog </p>
 * <p>Description: 请求日志</p>
 * <p>Copyright (c) 2020 </p>
 * <p>Company: 上海阳光喔科技有限公司</p>
 * @author bobo	
 * @date 2020年5月12日 下午5:17:39	
 * @version 1.0
 * <p>修改人：bobo</p>
 * <p>修改时间：2020年5月12日 下午5:17:39</p>
 * <p>修改备注：</p>
 */
@Data
public class RequestLog {

	private String resquestId;

	private String serviceName;

	private String requestIpAddr;

	private String serverIpAddr;

	private String url;

	private String queryParams;

	private long longTime;

	private String dateTimeStr;

	private String requestContentType;

	private String requestBody;

	private String responseBody;

	private int responseStatus;

	private int httpCode;

	private String responseContentType;

}

package com.ygw.es.config;

import java.time.Duration;
import java.util.Map;

import lombok.Data;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * <p>Title: ElasticsearchClientConfig </p>
 * <p>Description: es配置文件</p>
 * <p>Copyright (c) 2020 </p>
 * <p>Company: 上海阳光喔科技有限公司</p>
 *
 * @author bobo
 * @version 1.0
 * <p>修改人：bobo</p>
 * <p>修改时间：2020年5月7日 下午12:02:14</p>
 * <p>修改备注：</p>
 * @date 2020年5月7日 下午12:02:14
 */
@Data
@ConfigurationProperties(prefix = "ygw.elasticsearch")
public class ElasticsearchClientConfig {

    private String[] nodes;
    private Client client;
    private Pool pool;

    @Data
    public static class Client {
        /**
         * 连接超时时间
         */
        private int connectTimeout = -1;
        /**
         * 等待获取连接的时间
         */
        private int connectionRequestTimeout = -1;
        /**
         * httpClient参数,等待数据的时间,若不配置，如果不设置socketTimeout会导致，已经建立了tcp链接，在通信时，发送了请求报文，恰好此时，网络断掉，程序就阻塞，假死在那。
         */
        private int socketTimeout = -1;
        /**
         * httpClient参数,是同时间正在使用的最多的连接数
         */
        private int maxConnTotal = 0;
        /**
         * httpClient参数, 是针对一个域名同时间正在使用的最多的连接数
         */
        private int maxConnPerRoute = 0;
        private Map<String, String> headers;
    }

    /**
     * <p>Title: Pool </p>
     * <p>Description: 封装连接池配置（GenericObjectPoolConfig的封装）</p>
     * <p>Copyright (c) 2020 </p>
     * <p>Company: 上海阳光喔科技有限公司</p>
     *
     * @author bobo
     * @version 1.0
     * <p>修改人：bobo</p>
     * <p>修改时间：2020年5月8日 上午11:23:09</p>
     * <p>修改备注：</p>
     * @date 2020年5月8日 上午11:23:09
     */
    @Data
    public static class Pool {
        /**
         * 链接池中最大空闲的连接数,默认为8
         */
        private int maxIdle = 8;
        /**
         * 连接池中最少空闲的连接数,默认为0
         */
        private int minIdle = 0;
        /**
         * 可支持的最大连接数
         */
        private int maxActive = 8;
        private Duration maxWait = Duration.ofMillis(-1);
    }
}

package com.ygw.es.core;

import lombok.Builder;
import lombok.Data;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.aggregations.Aggregations;

/**
 * Title : SearchResult
 * Description: 查询结果集
 * Copyright (c) 2020
 * Company: 上海阳光喔科技有限公司
 * <p>
 * 修改人: bobo
 * 修改时间: 2020年05月22日 15:53
 * 修改备注:
 *
 * @author bobo
 * @version 1.0
 * @date 2020年05月22日 15:53
 */
@Data
@Builder
public class SearchResult {
    /**
     * 查询数据结果集
     */
    SearchHit[] searchHits;

    /**
     * 查询聚合函数结果集
     */
    Aggregations aggregations;


}

package com.ygw.es.connection;

import org.apache.http.HttpHost;

/**
 * 		
 * <p>Title: RestClientStandaloneConfiguration </p>
 * <p>Description: 单机配置</p>
 * <p>Copyright (c) 2020 </p>
 * <p>Company: 上海阳光喔科技有限公司</p>
 * @author bobo	
 * @date 2020年5月7日 下午12:01:33	
 * @version 1.0
 * <p>修改人：bobo</p>
 * <p>修改时间：2020年5月7日 下午12:01:33</p>
 * <p>修改备注：</p>
 */
public class RestClientStandaloneConfiguration extends RestClientConfiguration {

	private String host;
	private Integer port;

	public RestClientStandaloneConfiguration() {
	}

	public RestClientStandaloneConfiguration(String host, Integer port) {
		this.host = host;
		this.port = port;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public void setPort(Integer port) {
		this.port = port;
	}

	@Override
	public HttpHost[] getHttpHosts() {
		return new HttpHost[] { new HttpHost(host, port, "http") };
	}
}

package com.ygw.es.vo;

import lombok.Builder;
import lombok.Data;

import org.elasticsearch.search.sort.SortOrder;

import java.util.List;

/**
 * <p>Title: PageVO </p>
 * <p>Description: 分页对象</p>
 * <p>Copyright (c) 2020 </p>
 * <p>Company: 上海阳光喔科技有限公司</p>
 *
 * @author bobo
 * @version 1.0
 * <p>修改人：bobo</p>
 * <p>修改时间：2020年5月15日 下午2:07:18</p>
 * <p>修改备注：</p>
 * @date 2020年5月15日 下午2:07:18
 */
@Data
@Builder
public class PageVO {

    private int start;

    private int end;
}

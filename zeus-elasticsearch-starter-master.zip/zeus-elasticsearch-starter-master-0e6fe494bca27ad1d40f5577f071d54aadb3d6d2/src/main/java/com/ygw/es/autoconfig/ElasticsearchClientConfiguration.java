package com.ygw.es.autoconfig;

import java.util.ArrayList;
import java.util.List;

import lombok.extern.slf4j.Slf4j;

import org.apache.commons.pool2.impl.GenericObjectPool;
import org.elasticsearch.ElasticsearchException;
import org.elasticsearch.client.RestHighLevelClient;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.CollectionUtils;

import com.ygw.es.config.ElasticsearchClientConfig;
import com.ygw.es.connection.ElasticsearchClientFactory;
import com.ygw.es.connection.RestClientClusterConfiguration;
import com.ygw.es.connection.RestClientConfiguration;
import com.ygw.es.connection.RestClientPoolConfig;
import com.ygw.es.core.ElasticsearchNode;

/**
 * <p>Title: ElasticsearchClientConfiguration </p>
 * <p>Description: es客户端配置</p>
 * <p>Copyright (c) 2020 </p>
 * <p>Company: 上海阳光喔科技有限公司</p>
 *
 * @author bobo
 * @version 1.0
 * <p>修改人：bobo</p>
 * <p>修改时间：2020年5月7日 上午11:18:16</p>
 * <p>修改备注：</p>
 * @date 2020年5月7日 上午11:18:16
 */
@Slf4j
@Configuration
@ConditionalOnClass({GenericObjectPool.class, RestHighLevelClient.class})
public class ElasticsearchClientConfiguration {

    private final ElasticsearchClientConfig properties;

    public ElasticsearchClientConfiguration(ElasticsearchClientConfig properties) {
        this.properties = properties;
    }

    @Bean
    @ConditionalOnMissingBean
    public ElasticsearchClientFactory elasticsearchClientFactory() {
        log.info("=================== ElasticsearchClient 启动了 =======================");
        RestClientPoolConfig poolConfig = getPoolConfig();
        RestClientConfiguration clientConfiguration = getClientConfiguration();
        if (clientConfiguration == null) {
            log.info("=================== Elasticsearch clientConfiguration 未配置 =======================");
            return null;
        }
        ElasticsearchClientFactory factory = new ElasticsearchClientFactory(clientConfiguration, poolConfig);
        setDefaultHeaders(factory);
        return factory;
    }

    private RestClientPoolConfig getPoolConfig() {
        RestClientPoolConfig poolConfig = new RestClientPoolConfig();
        ElasticsearchClientConfig.Pool pool = properties.getPool();
        if (pool != null) {
            poolConfig.setMinIdle(pool.getMinIdle());
            poolConfig.setMaxIdle(pool.getMaxIdle());
            poolConfig.setMaxTotal(pool.getMaxActive());
            poolConfig.setMaxWaitMillis(pool.getMaxWait().toMillis());
            log.info("=================== Elasticsearch连接池 MaxIdle：{},MinIdle:{},MaxTotal:{},MaxWaitMillis:{}", poolConfig.getMaxIdle(),
                    poolConfig.getMinIdle(), poolConfig.getMaxTotal(), poolConfig.getMaxWaitMillis());

        }
        log.info("=================== Elasticsearch启用默认连接池 ======MaxIdle：{},MinIdle:{},MaxTotal:{},MaxWaitMillis:{}", poolConfig.getMaxIdle(),
                poolConfig.getMinIdle(), poolConfig.getMaxTotal(), poolConfig.getMaxWaitMillis());
        return poolConfig;
    }

    private RestClientConfiguration getClientConfiguration() {
        List<ElasticsearchNode> hosts = createHosts();
        if (CollectionUtils.isEmpty(hosts)) {
            return null;
        }
        RestClientConfiguration configuration = new RestClientClusterConfiguration(hosts);
        return customizeConfiguration(configuration);
    }

    private List<ElasticsearchNode> createHosts() {
        if (properties.getNodes() == null) {

            return null;
        }
        List<ElasticsearchNode> hosts = new ArrayList<>();
        try {
            for (String node : properties.getNodes()) {
                String[] hostPort = node.split(":");
                log.info("=================== ElasticsearchClient 启动端口IP：{}，端口号：{} =======================", hostPort[0],
                        Integer.parseInt(hostPort[1]));
                hosts.add(new ElasticsearchNode(hostPort[0], Integer.parseInt(hostPort[1])));
            }
            return hosts;
        } catch (NumberFormatException e) {
            throw new ElasticsearchException(e);
        }
    }

    private RestClientConfiguration customizeConfiguration(RestClientConfiguration configuration) {
        ElasticsearchClientConfig.Client client = properties.getClient();
        if (client != null) {
            configuration.setConnectTimeout(client.getConnectTimeout());
            configuration.setConnectionRequestTimeout(client.getConnectionRequestTimeout());
            configuration.setSocketTimeout(client.getSocketTimeout());
            configuration.setMaxConnTotal(client.getMaxConnTotal());
            configuration.setMaxConnPerRoute(client.getMaxConnPerRoute());
        }
        return configuration;
    }

    private void setDefaultHeaders(ElasticsearchClientFactory factory) {
        ElasticsearchClientConfig.Client client = properties.getClient();
        if (client != null && client.getHeaders() != null) {
            factory.setDefaultHeaders(client.getHeaders());
        }
    }
}

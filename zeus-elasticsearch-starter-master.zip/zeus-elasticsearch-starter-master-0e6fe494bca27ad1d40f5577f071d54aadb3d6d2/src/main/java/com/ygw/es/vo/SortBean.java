package com.ygw.es.vo;

import lombok.Builder;
import lombok.Data;
import org.elasticsearch.search.sort.SortOrder;

/**
 * Title : SortBean
 * Description: 排序bean对象
 * Copyright (c) 2020
 * Company: 上海阳光喔科技有限公司
 * <p>
 * 修改人: bobo
 * 修改时间: 2020年07月23日 15:37
 * 修改备注:
 *
 * @author bobo
 * @version 1.0
 * @date 2020年07月23日 15:37
 */
@Data
@Builder
public class SortBean {

    /**
     * 排序字段
     */
    private String sortField;

    /**
     * 排序顺序 SortOrder.ASC或者SortOrder.DESC
     */
    private SortOrder sortOrder;
}

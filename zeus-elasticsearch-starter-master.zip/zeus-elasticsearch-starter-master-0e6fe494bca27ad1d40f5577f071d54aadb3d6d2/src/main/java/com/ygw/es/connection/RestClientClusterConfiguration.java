package com.ygw.es.connection;

import java.util.List;

import org.apache.http.HttpHost;

import com.ygw.es.core.ElasticsearchNode;

/**
 * 		
 * <p>Title: RestClientClusterConfiguration </p>
 * <p>Description: es集群配置</p>
 * <p>Copyright (c) 2020 </p>
 * <p>Company: 上海阳光喔科技有限公司</p>
 * @author bobo	
 * @date 2020年5月7日 下午12:00:11	
 * @version 1.0
 * <p>修改人：bobo</p>
 * <p>修改时间：2020年5月7日 下午12:00:11</p>
 * <p>修改备注：</p>
 */
public class RestClientClusterConfiguration extends RestClientConfiguration {

	private List<ElasticsearchNode> clusterNodes;

	public RestClientClusterConfiguration() {

	}

	public RestClientClusterConfiguration(List<ElasticsearchNode> clusterNodes) {
		this.clusterNodes = clusterNodes;
	}

	public void setHosts(List<ElasticsearchNode> clusterNodes) {
		this.clusterNodes = clusterNodes;
	}

	@Override
	public HttpHost[] getHttpHosts() {
		HttpHost[] hostArray = new HttpHost[clusterNodes.size()];
		for (int i = 0; i < clusterNodes.size(); i++) {
			hostArray[i] = new HttpHost(clusterNodes.get(i).getHost(), clusterNodes.get(i).getPort(), "http");
		}
		return hostArray;
	}

}

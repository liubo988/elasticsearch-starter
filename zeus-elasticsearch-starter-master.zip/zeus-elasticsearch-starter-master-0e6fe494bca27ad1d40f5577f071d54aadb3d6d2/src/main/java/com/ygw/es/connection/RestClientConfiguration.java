package com.ygw.es.connection;

import lombok.Data;

import org.apache.http.HttpHost;

/**
 * 		
 * <p>Title: RestClientConfiguration </p>
 * <p>Description: 客户端配置</p>
 * <p>Copyright (c) 2020 </p>
 * <p>Company: 上海阳光喔科技有限公司</p>
 * @author bobo	
 * @date 2020年5月7日 下午12:00:29	
 * @version 1.0
 * <p>修改人：bobo</p>
 * <p>修改时间：2020年5月7日 下午12:00:29</p>
 * <p>修改备注：</p>
 */
@Data
public abstract class RestClientConfiguration {

	private int connectTimeout = -1;
	private int connectionRequestTimeout = -1;
	/**
	 * 接连超时时间
	 */
	private int socketTimeout = -1;

	/**
	 * HttpClient默认连接池，最大连接数(maxConnTotal)是20个，最大同路由(maxConnPerRoute)的是2个
	 */

	/**
	 * 是同时间正在使用的最多的连接数
	 */
	private int maxConnTotal = 0;
	/**
	 * 是针对一个域名同时间正在使用的最多的连接数
	 */
	private int maxConnPerRoute = 0;

	/**
	 * 
	 * getHttpHosts：获取节点集群端口号列表
	 * @return
	 * @exception	
	 * @author bobo
	 * @date 2020年5月8日 上午11:42:45
	 */
	abstract HttpHost[] getHttpHosts();
}

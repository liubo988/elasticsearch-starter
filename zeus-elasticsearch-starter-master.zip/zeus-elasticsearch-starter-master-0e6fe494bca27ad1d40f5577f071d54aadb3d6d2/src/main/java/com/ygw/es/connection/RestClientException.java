package com.ygw.es.connection;

/**
 * 		
 * <p>Title: RestClientException </p>
 * <p>Description: 异常类封装</p>
 * <p>Copyright (c) 2020 </p>
 * <p>Company: 上海阳光喔科技有限公司</p>
 * @author bobo	
 * @date 2020年5月7日 下午12:00:41	
 * @version 1.0
 * <p>修改人：bobo</p>
 * <p>修改时间：2020年5月7日 下午12:00:41</p>
 * <p>修改备注：</p>
 */
public class RestClientException extends RuntimeException {

	public RestClientException(String message) {
		super(message);
	}

	public RestClientException(String message, Throwable cause) {
		super(message, cause);
	}

	public RestClientException(Throwable cause) {
		super(cause);
	}
}

package com.ygw.es.connection;

import java.util.Map;

import lombok.extern.slf4j.Slf4j;

import org.elasticsearch.client.RestHighLevelClient;

/**
 * <p>Title: ElasticsearchClientFactory </p>
 * <p>Description:连接工厂配置</p>
 * <p>Copyright (c) 2020 </p>
 * <p>Company: 上海阳光喔科技有限公司</p>
 *
 * @author bobo
 * @version 1.0
 * <p>修改人：bobo</p>
 * <p>修改时间：2020年5月7日 上午11:59:38</p>
 * <p>修改备注：</p>
 * @date 2020年5月7日 上午11:59:38
 */
@Slf4j
public class ElasticsearchClientFactory {

    private RestClientPool<RestHighLevelClient> pool;// 连接池
    private Map<String, String> defaultHeaders;// 默认头

    public ElasticsearchClientFactory(RestClientConfiguration configuration, RestClientPoolConfig poolConfig) {
        createPool(configuration, poolConfig);
    }

    public void setDefaultHeaders(Map<String, String> defaultHeaders) {
        this.defaultHeaders = defaultHeaders;
    }

    public RestHighLevelClient getResource() {
        return pool.getResource();
    }

    public void returnResource(RestHighLevelClient restHighLevelClient) {
        pool.returnResource(restHighLevelClient);
    }

    public void close() {
        if (pool != null) {
            log.info("=================== Elasticsearch 服务关闭! =======================");
            pool.close();
        }
    }

    private void createPool(RestClientConfiguration configuration, RestClientPoolConfig poolConfig) {
        RestHighLevelClientFactory clientFactory = new RestHighLevelClientFactory(configuration, defaultHeaders);
        pool = new RestClientPool<>(poolConfig, clientFactory);
    }

}

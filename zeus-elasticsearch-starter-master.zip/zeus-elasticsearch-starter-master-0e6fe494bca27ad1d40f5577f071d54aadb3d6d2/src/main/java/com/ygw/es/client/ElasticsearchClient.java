package com.ygw.es.client;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.google.gson.GsonBuilder;
import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.action.ActionListener;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.bulk.BulkResponse;
import org.elasticsearch.action.delete.DeleteRequest;
import org.elasticsearch.action.delete.DeleteResponse;
import org.elasticsearch.action.get.GetRequest;
import org.elasticsearch.action.get.GetResponse;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.action.update.UpdateRequest;
import org.elasticsearch.action.update.UpdateResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.common.xcontent.XContentType;
import org.elasticsearch.search.builder.SearchSourceBuilder;

import com.google.gson.Gson;
import com.ygw.es.client.operations.DocumentOperations;
import com.ygw.es.client.operations.IndicesOperations;
import com.ygw.es.client.operations.QueryOperations;
import com.ygw.es.connection.ElasticsearchClientFactory;
import com.ygw.es.core.BeanUtils;
import com.ygw.es.core.Constants;
import com.ygw.es.core.ElasticsearchAccessException;
import com.ygw.es.core.RestClientAccessor;
import com.ygw.es.core.RestClientAsyncCallback;
import com.ygw.es.core.RestClientCallback;
import com.ygw.es.core.UUIDGenerator;
import org.springframework.util.ObjectUtils;

/**
 * <p>Title: ElasticsearchClient </p>
 * <p>Description: 客户端操作类</p>
 * <p>Copyright (c) 2020 </p>
 * <p>Company: 上海阳光喔科技有限公司</p>
 *
 * @author bobo
 * @version 1.0
 * <p>修改人：bobo</p>
 * <p>修改时间：2020年5月7日 下午12:10:02</p>
 * <p>修改备注：</p>
 * @date 2020年5月7日 下午12:10:02
 */
@Slf4j
public class ElasticsearchClient extends RestClientAccessor implements DocumentOperations {

    private QueryOperations queryOperations;

    private IndicesOperations indicesOperations;

    public ElasticsearchClient() {
    }

    public ElasticsearchClient(ElasticsearchClientFactory restClientFactory) {
        setConnectionFactory(restClientFactory);
    }

    @Override
    public <T> T execute(RestClientCallback<T> callback) {
        try {
            ElasticsearchClientFactory clientFactory = getRestClientFactory();
            RestHighLevelClient client = clientFactory.getResource();
            T t = callback.doInRestClient(client);
            clientFactory.returnResource(client);
            return t;
        } catch (IOException e) {
            throw new ElasticsearchAccessException(e);
        }
    }

    @Override
    public void asyncExecute(RestClientAsyncCallback callback) {
        try {
            RestHighLevelClient client = getRestClientFactory().getResource();
            callback.doInRestAsyncClient(client);
            getRestClientFactory().returnResource(client);
        } catch (IOException e) {
            throw new ElasticsearchAccessException(e);
        }
    }

    @Override
    public IndexResponse persist(IndexRequest request) {
        RestHighLevelClient client = getRestClientFactory().getResource();

        try {
            return client.index(request, RequestOptions.DEFAULT);
        } catch (IOException e) {
        }
        return null;
    }

    @Override
    public IndexResponse insert(String indexName, Object document) {
        setDefaultCreateTime(document);//设置默认更新时间
        String id = getId(document);//获取对象id
        String json = new Gson().toJson(document);
        IndexRequest request = new IndexRequest(indexName).id(id).source(json, XContentType.JSON);
        return persist(request);
    }

    @Override
    public void insertAsync(String indexName, Object document, ActionListener<IndexResponse> listener) {
        String json = new Gson().toJson(document);
        IndexRequest request = new IndexRequest(indexName).id(UUIDGenerator.getUUID32Bit()).source(json, XContentType.JSON);
        persist(request, listener);
    }

    @Override
    public UpdateResponse update(UpdateRequest request) {
        return execute((highLevelClient) -> {
            return highLevelClient.update(request, RequestOptions.DEFAULT);
        });
    }

    @Override
    public DeleteResponse delete(DeleteRequest request) {
        return execute((highLevelClient) -> {
            return highLevelClient.delete(request, RequestOptions.DEFAULT);
        });
    }

    @Override
    public Map<String, Object> get(GetRequest request) {
        return execute((highLevelClient) -> {
            GetResponse response = highLevelClient.get(request, RequestOptions.DEFAULT);
            return response.getSourceAsMap();
        });
    }

    public QueryOperations getInstance() {
        if (queryOperations == null) {
            queryOperations = new DefaultQueryOperations(this, new SearchSourceBuilder());
        } else {
            ((DefaultQueryOperations) queryOperations).setSearchSourceBuilder(new SearchSourceBuilder());
        }
        return queryOperations;
    }

    public IndicesOperations indices() {
        if (indicesOperations == null) {

            indicesOperations = new DefaultIndicesOperations(this);
        }
        return indicesOperations;
    }

    /**
     * --------------------------以下为异步方法----------------------------------
     */

    @Override
    public void persist(IndexRequest request, ActionListener<IndexResponse> listener) {
        asyncExecute((highLevelClient) -> {
            highLevelClient.indexAsync(request, RequestOptions.DEFAULT, listener);
        });
    }

    @Override
    public void update(UpdateRequest request, ActionListener<UpdateResponse> listener) {
        asyncExecute((highLevelClient) -> {
            highLevelClient.updateAsync(request, RequestOptions.DEFAULT, listener);
        });
    }

    @Override
    public void delete(DeleteRequest request, ActionListener<DeleteResponse> listener) {
        asyncExecute((highLevelClient) -> {
            highLevelClient.deleteAsync(request, RequestOptions.DEFAULT, listener);
        });
    }

    @Override
    public void get(GetRequest request, ActionListener<GetResponse> listener) {
        asyncExecute((highLevelClient) -> {
            highLevelClient.getAsync(request, RequestOptions.DEFAULT, listener);
        });
    }

    /**
     * --------------------------异步方法结束----------------------------------
     */

    @Override
    public <T, K, V> T findById(String indexName, String documentId, Class<?> clazz) {
        // 根据id查找文档
        GetRequest request = new GetRequest(indexName).id(documentId);
        Map<String, Object> map = this.get(request);
        if (null == map) {//如果返回null，则返回null;
            return null;
        }
        return (T) BeanUtils.map2Bean(map, clazz);
    }

    @Override
    public UpdateResponse update(String indexName, Object document) {
        try {
            setDefaultUpdateTime(document);//设置默认更新时间
            //空属性也要创建
            Gson gson = new GsonBuilder().serializeNulls().create();
            String json = gson.toJson(document);
            Field field = document.getClass().getSuperclass().getDeclaredField(Constants.ID);
            field.setAccessible(true);// 暴力访问
            String id = (String) field.get(document);
            UpdateRequest request = new UpdateRequest(indexName, id).doc(json, XContentType.JSON);
            return execute((highLevelClient) -> {
                return highLevelClient.update(request, RequestOptions.DEFAULT);
            });
        } catch (Exception e) {
            throw new ElasticsearchAccessException(e);
        }
    }

    @Override
    public UpdateResponse updateSelectiveById(String indexName, Object document) {
        try {
            setDefaultUpdateTime(document);//设置默认更新时间
            String json = new Gson().toJson(document);
            Field field = document.getClass().getSuperclass().getDeclaredField(Constants.ID);
            field.setAccessible(true);// 暴力访问
            String id = (String) field.get(document);
            UpdateRequest request = new UpdateRequest(indexName, id).doc(json, XContentType.JSON);
            return execute((highLevelClient) -> {
                return highLevelClient.update(request, RequestOptions.DEFAULT);
            });
        } catch (Exception e) {
            throw new ElasticsearchAccessException(e);
        }
    }

    @Override
    public DeleteResponse deleteById(String indexName, String documentId) {
        DeleteRequest request = new DeleteRequest(indexName).id(documentId);
        return execute((highLevelClient) -> {
            return highLevelClient.delete(request, RequestOptions.DEFAULT);
        });
    }

    @Override
    public BulkResponse insertList(String indexName, List documents) {
        RestHighLevelClient client = getRestClientFactory().getResource();
        BulkRequest bulkRequest = new BulkRequest();
        try {
            documents.forEach(document -> {
                String json = new Gson().toJson(document);
                bulkRequest.add(new IndexRequest(indexName).id(UUIDGenerator.getUUID32Bit()).source(json, XContentType.JSON));
            });
            return client.bulk(bulkRequest, RequestOptions.DEFAULT);
        } catch (IOException e) {
        }
        return null;
    }

    @Override
    public void setDefaultUpdateTime(Object document) {
        try {
            Field longTimeField = document.getClass().getSuperclass().getDeclaredField(Constants.UPDATE_TIME_LONG);
            longTimeField.setAccessible(true);// 暴力访问
            longTimeField.set(document, System.currentTimeMillis());

            Field strTimeField = document.getClass().getSuperclass().getDeclaredField(Constants.UPDATE_TIME_STR);
            strTimeField.setAccessible(true);// 暴力访问
            strTimeField.set(document, Constants.sdfTime.format(new Date()));
        } catch (NoSuchFieldException | IllegalAccessException e) {
            log.info("[ElasticsearchClient]_setDefaultUpdateTime()方法异常：", e.getMessage());
            e.printStackTrace();
        }
    }


    /**
     * 反射设置默认创建时间
     *
     * @param document
     */
    private void setDefaultCreateTime(Object document) {
        try {
            Field longTimeField = document.getClass().getSuperclass().getDeclaredField(Constants.CREATE_TIME_LONG);
            longTimeField.setAccessible(true);// 暴力访问
            longTimeField.set(document, System.currentTimeMillis());
            Field strTimeField = document.getClass().getSuperclass().getDeclaredField(Constants.CREATE_TIME_STR);
            strTimeField.setAccessible(true);// 暴力访问
            strTimeField.set(document, Constants.sdfTime.format(new Date()));
        } catch (NoSuchFieldException | IllegalAccessException e) {
            log.info("[ElasticsearchClient]_setDefaultCreateime()方法异常：", e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * 获取对象的id
     *
     * @param document
     * @return
     */
    private String getId(Object document) {
        try {
            Field idField = document.getClass().getSuperclass().getDeclaredField(Constants.ID);
            if (null == idField) {//如果Field不存在 返回UUID
                return UUIDGenerator.getUUID32Bit();
            }
            idField.setAccessible(true);// 暴力访问
            String id = (String) idField.get(document);
            if (null == id) {//如果ID不存在 返回UUID
                return UUIDGenerator.getUUID32Bit();
            }
            return id;
        } catch (Exception e) {
            log.info("[ElasticsearchClient]_____________getId()方法异常：", e.getMessage());
            e.printStackTrace();
        }
        return null;
    }
}

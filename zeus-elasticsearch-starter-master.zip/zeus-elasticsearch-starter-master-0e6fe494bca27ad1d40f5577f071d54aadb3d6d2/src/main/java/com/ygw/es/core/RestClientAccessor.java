package com.ygw.es.core;

import com.ygw.es.connection.ElasticsearchClientFactory;

/**
 * 		
 * <p>Title: RestClientAccessor </p>
 * <p>Description: client处理封装</p>
 * <p>Copyright (c) 2020 </p>
 * <p>Company: 上海阳光喔科技有限公司</p>
 * @author bobo	
 * @date 2020年5月7日 下午12:04:55	
 * @version 1.0
 * <p>修改人：bobo</p>
 * <p>修改时间：2020年5月7日 下午12:04:55</p>
 * <p>修改备注：</p>
 */
public class RestClientAccessor {

	private ElasticsearchClientFactory restClientFactory;

	public RestClientAccessor() {
	}

	public RestClientAccessor(ElasticsearchClientFactory restClientFactory) {
		this.restClientFactory = restClientFactory;
	}

	public void setConnectionFactory(ElasticsearchClientFactory restClientFactory) {
		this.restClientFactory = restClientFactory;
	}

	public ElasticsearchClientFactory getRestClientFactory() {
		if (restClientFactory == null) {
			throw new IllegalStateException("RestHighLevelClientFactory is required");
		}
		return restClientFactory;
	}
}

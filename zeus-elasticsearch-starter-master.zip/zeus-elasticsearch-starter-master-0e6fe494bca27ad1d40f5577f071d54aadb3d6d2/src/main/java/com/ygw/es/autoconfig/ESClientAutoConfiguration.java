package com.ygw.es.autoconfig;

import lombok.extern.slf4j.Slf4j;

import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import com.ygw.es.client.ElasticsearchClient;
import com.ygw.es.client.operations.DocumentOperations;
import com.ygw.es.config.ElasticsearchClientConfig;
import com.ygw.es.connection.ElasticsearchClientFactory;

/**
 * <p>Title: ESClientAutoConfiguration </p>
 * <p>Description: es自动注入</p>
 * <p>Copyright (c) 2020 </p>
 * <p>Company: 上海阳光喔科技有限公司</p>
 *
 * @author bobo
 * @version 1.0
 * <p>修改人：bobo</p>
 * <p>修改时间：2020年5月7日 下午12:15:17</p>
 * <p>修改备注：</p>
 * @date 2020年5月7日 下午12:15:17
 */
@Configuration
@ConditionalOnProperty(prefix = "ygw.elasticsearch", value = "enabled", havingValue = "true", matchIfMissing = true)
@ConditionalOnClass({DocumentOperations.class})
@Import(ElasticsearchClientConfiguration.class)
@EnableConfigurationProperties(ElasticsearchClientConfig.class)
@Slf4j
public class ESClientAutoConfiguration {

    @Bean
    @ConditionalOnBean(ElasticsearchClientFactory.class)
    public ElasticsearchClient restClientTemplate(ElasticsearchClientFactory factory) {
        return new ElasticsearchClient(factory);
    }

}

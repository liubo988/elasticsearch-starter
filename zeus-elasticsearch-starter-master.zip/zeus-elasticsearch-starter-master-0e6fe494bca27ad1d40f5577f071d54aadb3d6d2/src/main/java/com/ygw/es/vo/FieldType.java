package com.ygw.es.vo;

import org.elasticsearch.common.io.stream.StreamInput;
import org.elasticsearch.common.io.stream.StreamOutput;
import org.elasticsearch.common.io.stream.Writeable;
import org.elasticsearch.search.sort.SortOrder;

import java.io.IOException;
import java.util.Locale;

/**
 * Title : Field
 * Description: 类描述
 * Copyright (c) 2020
 * Company: 上海阳光喔科技有限公司
 * <p>
 * 修改人: bobo
 * 修改时间: 2020年07月24日 17:07
 * 修改备注:
 *
 * @author bobo
 * @version 1.0
 * @date 2020年07月24日 17:07
 */
public enum FieldType {

    /**
     * int型字段，如:int，long，double 等等
     */
    NUMBER("number"),
    /**
     * 文本型字段，如string。date等等
     */
    TEXT("text");

    private final String value;

    FieldType(String value) {
        this.value = value;
    }

    public String toString() {
        return this.value.toString();
    }


}

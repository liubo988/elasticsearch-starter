package com.ygw.es.core;

import org.elasticsearch.search.fetch.subphase.highlight.HighlightBuilder;

/**
 * 		
 * <p>Title: HighlightUtils </p>
 * <p>Description: 高亮工具包</p>
 * <p>Copyright (c) 2020 </p>
 * <p>Company: 上海阳光喔科技有限公司</p>
 * @author bobo	
 * @date 2020年5月7日 下午12:04:28	
 * @version 1.0
 * <p>修改人：bobo</p>
 * <p>修改时间：2020年5月7日 下午12:04:28</p>
 * <p>修改备注：</p>
 */
public class HighlightUtils {

	public static HighlightBuilder createHighlightBuilder(HighlightType type, String... fields) {
		HighlightBuilder highlightBuilder = new HighlightBuilder();
		for (String field : fields) {
			HighlightBuilder.Field highlightField = new HighlightBuilder.Field(field);
			highlightField.highlighterType(type.getValue());
			highlightBuilder.field(highlightField);
		}
		return highlightBuilder;
	}
}

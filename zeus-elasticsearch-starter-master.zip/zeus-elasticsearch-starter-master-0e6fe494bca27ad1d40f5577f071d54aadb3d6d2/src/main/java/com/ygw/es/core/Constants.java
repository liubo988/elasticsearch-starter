package com.ygw.es.core;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * <p>Title: Constants </p>
 * <p>Description: 常量类</p>
 * <p>Copyright (c) 2020 </p>
 * <p>Company: 上海阳光喔科技有限公司</p>
 *
 * @author bobo
 * @version 1.0
 * <p>修改人：bobo</p>
 * <p>修改时间：2020年5月9日 下午3:07:00</p>
 * <p>修改备注：</p>
 * @date 2020年5月9日 下午3:07:00
 */
public class Constants {

    /**
     * 主键id字段
     */
    public static String ID = "id";

    public static String UPDATE_TIME_LONG = "lastUpdateTime";

    public static String UPDATE_TIME_STR = "lastUpdateTimeStr";


    public static String CREATE_TIME_LONG = "createTime";

    public static String CREATE_TIME_STR = "createTimeStr";

    public static final SimpleDateFormat sdfTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");


    /**
     * 默认查询最大数据条数
     */
    public static Integer DEFAULT_MAX_SIZE = 10000;

    /**
     * 聚合最大值
     */
    public static String AggregationMAX = "max";
    /**
     * 聚合最小值
     */
    public static String AggregationMIN = "min";

    /**
     * 聚合平均值
     */
    public static String AggregationAVG = "avg";

    /**
     * 查询关键字(text格式属性不支持聚合查询,查询字段加上.keyword 表示使用完整的字段，无需修改es，也无需修改代码逻辑)
     */
    public static String SEARCH_KEYWORD = ".keyword";

    public static String NUMBER_CLASS = "class java.lang.Number";

    /**
     * @param lo 毫秒�?
     * @return String yyyy-MM-dd HH:mm:ss
     * @Description: 字符串类型转换成时间戳类�?
     */
    public static long stringToLong(String time) {
        long timeStemp = 0;
        try {
            Date d = sdfTime.parse(time);
            timeStemp = d.getTime();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return timeStemp;
    }
}

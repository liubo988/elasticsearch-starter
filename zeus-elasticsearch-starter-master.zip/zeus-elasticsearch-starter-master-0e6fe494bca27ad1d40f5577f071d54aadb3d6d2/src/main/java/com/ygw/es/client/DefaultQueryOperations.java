package com.ygw.es.client;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Stream;

import com.ygw.es.core.Constants;
import com.ygw.es.core.SearchResult;
import com.ygw.es.vo.FieldType;
import com.ygw.es.vo.SortBean;
import lombok.val;
import org.elasticsearch.action.ActionListener;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.common.text.Text;
import org.elasticsearch.common.unit.TimeValue;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.MatchAllQueryBuilder;
import org.elasticsearch.index.query.MatchQueryBuilder;
import org.elasticsearch.index.query.MultiMatchQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.RangeQueryBuilder;
import org.elasticsearch.index.query.TermQueryBuilder;
import org.elasticsearch.index.query.TermsQueryBuilder;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.aggregations.Aggregation;
import org.elasticsearch.search.aggregations.AggregationBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.metrics.Avg;
import org.elasticsearch.search.aggregations.metrics.Max;
import org.elasticsearch.search.aggregations.metrics.Min;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.elasticsearch.search.fetch.subphase.highlight.HighlightBuilder;
import org.elasticsearch.search.fetch.subphase.highlight.HighlightField;
import org.elasticsearch.search.sort.SortBuilder;
import org.elasticsearch.search.sort.SortBuilders;
import org.elasticsearch.search.sort.SortOrder;

import com.ygw.es.client.operations.QueryOperations;
import com.ygw.es.core.BeanUtils;
import com.ygw.es.core.ElasticsearchAccessException;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;

import javax.security.auth.login.Configuration;

/**
 * <p>Title: DefaultQueryOperations </p>
 * <p>Description: 默认查询操作</p>
 * <p>Copyright (c) 2020 </p>
 * <p>Company: 上海阳光喔科技有限公司</p>
 *
 * @author bobo
 * @version 1.0
 * <p>修改人：bobo</p>
 * <p>修改时间：2020年5月7日 上午10:37:23</p>
 * <p>修改备注：</p>
 * @date 2020年5月7日 上午10:37:23
 */
class DefaultQueryOperations implements QueryOperations {

    private ElasticsearchClient template;
    private SearchSourceBuilder builder;
    private HighlightBuilder highlightBuilder;


    public DefaultQueryOperations(ElasticsearchClient template, SearchSourceBuilder builder) {
        this.template = template;
        this.builder = builder;
    }

    DefaultQueryOperations setSearchSourceBuilder(SearchSourceBuilder builder) {
        this.builder = builder;
        return this;
    }

    @Override
    public <T> List<T> match(String index, MatchQueryBuilder queryBuilder, Class<?> clazz) {
        return execute(index, queryBuilder, clazz);
    }

    @Override
    public void match(String index, MatchQueryBuilder queryBuilder, ActionListener<SearchResponse> listener) {
        execute(index, queryBuilder, listener);
    }

    @Override
    public <T> List<T> matchAll(String index, MatchAllQueryBuilder queryBuilder, Class<?> clazz) {
        return execute(index, queryBuilder, clazz);
    }

    @Override
    public void matchAll(String index, MatchAllQueryBuilder queryBuilder, ActionListener<SearchResponse> listener) {
        execute(index, queryBuilder, listener);
    }

    @Override
    public <T> List<T> multiMatch(String index, MultiMatchQueryBuilder queryBuilder, Class<?> clazz) {
        return execute(index, queryBuilder, clazz);
    }

    @Override
    public void multiMatch(String index, MultiMatchQueryBuilder queryBuilder, ActionListener<SearchResponse> listener) {
        execute(index, queryBuilder, listener);
    }

    @Override
    public <T> List<T> term(String index, TermQueryBuilder queryBuilder, Class<?> clazz) {
        return execute(index, queryBuilder, clazz);
    }

    @Override
    public void term(String index, TermQueryBuilder queryBuilder, ActionListener<SearchResponse> listener) {
        execute(index, queryBuilder, listener);
    }

    @Override
    public <T> List<T> terms(String index, TermsQueryBuilder queryBuilder, Class<?> clazz) {
        return execute(index, queryBuilder, clazz);
    }

    @Override
    public void terms(String index, TermsQueryBuilder queryBuilder, ActionListener<SearchResponse> listener, Object... param) {
        execute(index, queryBuilder, listener);
    }

    @Override
    public <T> List<T> range(String index, RangeQueryBuilder queryBuilder, Class<?> clazz) {
        return execute(index, queryBuilder, clazz);
    }

    @Override
    public void range(String index, RangeQueryBuilder queryBuilder, ActionListener<SearchResponse> listener) {
        execute(index, queryBuilder, listener);
    }

    @Override
    public <T> List<T> bool(String index, BoolQueryBuilder queryBuilder, Class<?> clazz) {
        return execute(index, queryBuilder, clazz);
    }

    @Override
    public Integer count(String index, BoolQueryBuilder queryBuilder) {
        return template.execute((highLevelClient) -> {
            builder.query(queryBuilder);
            Integer count = executeQueryCount(index, highLevelClient);
            if (ObjectUtils.isEmpty(count)) {
                return 0;
            }
            return count;
        });
    }


    @Override
    public void bool(String index, BoolQueryBuilder queryBuilder, ActionListener<SearchResponse> listener) {
        execute(index, queryBuilder, listener);
    }

    private <T> List<T> execute(String index, QueryBuilder queryBuilder, Class<?> clazz) {
        return template.execute((highLevelClient) -> {
            builder.query(queryBuilder);
            return executeQuery(index, highLevelClient, clazz);
        });
    }

    private void execute(String index, QueryBuilder queryBuilder, ActionListener<SearchResponse> listener) {
        template.asyncExecute((highLevelClient) -> {
            builder.query(queryBuilder);
            executeAsyncQuery(index, highLevelClient, listener);
        });
    }

    private <T> List<T> executeQuery(String index, RestHighLevelClient client, Class<?> clazz) throws IOException {
        List<Map<String, Object>> listResult = new ArrayList<>();
        SearchRequest request = new SearchRequest(index);
        if (highlightBuilder != null) {
            builder.highlighter(highlightBuilder);
            SearchHit[] hits = search(request, client);

            for (SearchHit hit : hits) {

                resolveHighlightFields(hit);
                listResult.add(hit.getSourceAsMap());
            }
        } else {
            SearchResult sr = searchData(request, client);

            Map<String, Double> aggregationMap = new ConcurrentHashMap<>();
            if (null != sr.getAggregations()) {
                for (Aggregation aggregation : sr.getAggregations().asList()) {
                    String aggName = aggregation.getName();
                    if (aggName.contains(Constants.AggregationMAX)) {
                        Max max = sr.getAggregations().get(aggName);
                        aggregationMap.put(aggName, max.getValue());
                    } else if (aggName.contains(Constants.AggregationMIN)) {
                        Min min = sr.getAggregations().get(aggName);
                        aggregationMap.put(aggName, min.getValue());
                    } else if (aggName.contains(Constants.AggregationAVG)) {
                        Avg avg = sr.getAggregations().get(aggName);
                        aggregationMap.put(aggName, avg.getValue());
                    }

                }
            }

            for (SearchHit hit : sr.getSearchHits()) {
                // id赋值
                if (null != hit.getId()) {
                    hit.getSourceAsMap().put("id", hit.getId());
                }
                if (!CollectionUtils.isEmpty(aggregationMap)) {
                    hit.getSourceAsMap().putAll(aggregationMap);
                }
                listResult.add(hit.getSourceAsMap());
            }
        }

        List result = new ArrayList<>();
        for (Map<String, Object> map : listResult) {
            try {
                result.add((T) BeanUtils.map2Bean(map, clazz.newInstance().getClass()));
            } catch (Exception e) {
                throw new ElasticsearchAccessException(e);
            }
        }

        return result;
    }

    private Integer executeQueryCount(String index, RestHighLevelClient client) throws IOException {
        SearchRequest request = new SearchRequest(index);
        if (highlightBuilder != null) {
            builder.highlighter(highlightBuilder);
            SearchHit[] hits = search(request, client);
            if (ObjectUtils.isEmpty(hits)) {
                return null;
            }
            return hits.length;
        }
        SearchResult sr = searchData(request, client);
        if (ObjectUtils.isEmpty(sr) || ObjectUtils.isEmpty(sr.getSearchHits())) {
            return null;
        }
        return sr.getSearchHits().length;
    }

    private void resolveHighlightFields(SearchHit hit) {
        Map<String, HighlightField> highlightFields = hit.getHighlightFields();
        for (Map.Entry<String, HighlightField> entry : highlightFields.entrySet()) {
            HighlightField highlight = highlightFields.get(entry.getKey());
            if (highlight != null) {
                Text[] fragments = highlight.fragments();
                String fragmentString = fragments[0].string();
                hit.getSourceAsMap().put(entry.getKey(), fragmentString);
            }
        }
    }

    private SearchHit[] search(SearchRequest request, RestHighLevelClient client) throws IOException {
        builder.size(Constants.DEFAULT_MAX_SIZE);
        request.source(builder);
        SearchResponse response = client.search(request, RequestOptions.DEFAULT);
        SearchHit[] hits = response.getHits().getHits();
        return hits;
    }

    private SearchResult searchData(SearchRequest request, RestHighLevelClient client) throws IOException {
        //  builder.size(Constants.DEFAULT_MAX_SIZE);
        request.source(builder);
        SearchResponse response = client.search(request, RequestOptions.DEFAULT);
        SearchHit[] hits = response.getHits().getHits();
        SearchResult searchResult = SearchResult.builder().searchHits(hits).aggregations(response.getAggregations()).build();
        return searchResult;
    }

    private void executeAsyncQuery(String index, RestHighLevelClient client, ActionListener<SearchResponse> listener) {
        SearchRequest request = new SearchRequest(index);
        if (highlightBuilder != null) {
            builder.highlighter(highlightBuilder);
        }
        request.source(builder);
        client.searchAsync(request, RequestOptions.DEFAULT, listener);
    }

    @Override
    public QueryOperations highlight(HighlightBuilder highlightBuilder) {
        this.highlightBuilder = highlightBuilder;
        return this;
    }

    @Override
    public QueryOperations timeout(long timeout) {
        builder.timeout(TimeValue.timeValueNanos(timeout));
        return this;
    }

    @Override
    public QueryOperations from(int from) {
        builder.from(from);
        return this;
    }

    @Override
    public QueryOperations size(int size) {
        builder.size(size);
        return this;
    }

    @Override
    public QueryOperations pageSize(int start, int end) {
        builder.from(start).size(end);
        return this;
    }

    @Override
    public QueryOperations sort(String field, SortOrder order) {
        builder.sort(field, order);
        return this;
    }

    @Override
    public QueryOperations sort(String key, SortOrder order, FieldType type) {
        if (StringUtils.isEmpty(key) || StringUtils.isEmpty(order)) {
            return this;
        }
        if (!ObjectUtils.isEmpty(type) && type.equals(FieldType.TEXT)) {//如果参数类是字符串，需要拼接处理
            key += Constants.SEARCH_KEYWORD;
        }
        builder.sort(key, order);
        return this;
    }

    @Override
    public QueryOperations aggregations(AggregationBuilder aggregationBuilder) {
        builder.aggregation(aggregationBuilder);
        return this;
    }

    @Override
    public void max(String newField, String handleField) {
        AggregationBuilder aggregationBuilder = AggregationBuilders.max(newField).field(handleField);
        builder.aggregation(aggregationBuilder);
    }

    @Override
    public void min(String newField, String handleField) {
        AggregationBuilder aggregationBuilder = AggregationBuilders.min(newField).field(handleField);
        builder.aggregation(aggregationBuilder);
    }

    @Override
    public void avg(String newField, String handleField) {
        AggregationBuilder aggregationBuilder = AggregationBuilders.avg(newField).field(handleField);
        builder.aggregation(aggregationBuilder);
    }

}

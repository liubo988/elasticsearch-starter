package com.ygw.es.client.operations;

import java.util.List;

import com.ygw.es.vo.FieldType;
import com.ygw.es.vo.SortBean;
import org.elasticsearch.action.ActionListener;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.MatchAllQueryBuilder;
import org.elasticsearch.index.query.MatchQueryBuilder;
import org.elasticsearch.index.query.MultiMatchQueryBuilder;
import org.elasticsearch.index.query.RangeQueryBuilder;
import org.elasticsearch.index.query.TermQueryBuilder;
import org.elasticsearch.index.query.TermsQueryBuilder;
import org.elasticsearch.search.aggregations.AggregationBuilder;
import org.elasticsearch.search.fetch.subphase.highlight.HighlightBuilder;
import org.elasticsearch.search.sort.SortBuilder;
import org.elasticsearch.search.sort.SortOrder;

/**
 * <p>Title: QueryOperations </p>
 * <p>Description: 查询操作接口</p>
 * <p>Copyright (c) 2020 </p>
 * <p>Company: 上海阳光喔科技有限公司</p>
 *
 * @author bobo
 * @version 1.0
 * <p>修改人：bobo</p>
 * <p>修改时间：2020年5月7日 上午10:37:33</p>
 * <p>修改备注：</p>
 * @date 2020年5月7日 上午10:37:33
 */
public interface QueryOperations {

    <T> List<T> match(String index, MatchQueryBuilder queryBuilder, Class<?> clazz);

    void match(String index, MatchQueryBuilder queryBuilder, ActionListener<SearchResponse> listener);

    <T> List<T> matchAll(String index, MatchAllQueryBuilder queryBuilder, Class<?> clazz);

    void matchAll(String index, MatchAllQueryBuilder queryBuilder, ActionListener<SearchResponse> listener);

    <T> List<T> multiMatch(String index, MultiMatchQueryBuilder queryBuilder, Class<?> clazz);

    void multiMatch(String index, MultiMatchQueryBuilder queryBuilder, ActionListener<SearchResponse> listener);

    <T> List<T> term(String index, TermQueryBuilder queryBuilder, Class<?> clazz);

    void term(String index, TermQueryBuilder queryBuilder, ActionListener<SearchResponse> listener);

    <T> List<T> terms(String index, TermsQueryBuilder queryBuilder, Class<?> clazz);

    void terms(String index, TermsQueryBuilder queryBuilder, ActionListener<SearchResponse> listener, Object... param);

    <T> List<T> range(String index, RangeQueryBuilder queryBuilder, Class<?> clazz);

    void range(String index, RangeQueryBuilder queryBuilder, ActionListener<SearchResponse> listener);

    <T> List<T> bool(String index, BoolQueryBuilder queryBuilder, Class<?> clazz);

    /**
     * 查询数据条数
     *
     * @param index        索引名
     * @param queryBuilder 查询条件
     * @return
     */
    Integer count(String index, BoolQueryBuilder queryBuilder);

    void bool(String index, BoolQueryBuilder queryBuilder, ActionListener<SearchResponse> listener);

    QueryOperations highlight(HighlightBuilder highlightBuilder);


    QueryOperations timeout(long timeout);

    QueryOperations from(int from);

    QueryOperations size(int size);

    QueryOperations pageSize(int startSize, int endSize);

    QueryOperations sort(String field, SortOrder order);

    /**
     * 排序
     *
     * @param key       排序字段
     * @param order     排序顺序
     * @param type 参数类型
     * @return
     * @author bobo
     */
    QueryOperations sort(String key, SortOrder order, FieldType type);

    QueryOperations aggregations(AggregationBuilder aggregationBuilder);

    void max(String newField, String handleField);

    void min(String newField, String handleField);

    void avg(String newField, String handleField);
}

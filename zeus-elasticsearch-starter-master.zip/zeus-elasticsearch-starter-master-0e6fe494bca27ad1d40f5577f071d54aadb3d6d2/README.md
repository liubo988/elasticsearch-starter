# zeus-elasticsearch-starter
## 在spring boot中使用spring-elasticsearch-client

### 1. 依赖

~~~xml
<dependency>
     <groupId>com.ygw</groupId>
     <artifactId>zeus-elasticsearch-starter</artifactId>
     <version>0.0.2-SNAPSHOT</version>
</dependency>
~~~

注意，由于依赖的是elasticsearch-rest-high-level-client 7.5.0版本，需要替换spring boot集成的低版本，避免依赖冲突。

~~~xml
<properties>
      <!-- 替换spring boot的低版本 -->
      <elasticsearch.version>7.5.0</elasticsearch.version>
</properties>
~~~

### 2. application.yml配置

~~~yml
ygw:
  elasticsearch:
    nodes:
      - 192.168.0.100:9200
      - 192.168.0.101:9200
      - 192.168.0.102:9200
    client:
      connect-timeout: 1000
      connection-request-timeout: 500
      socket-timeout: 20000
      max-conn-total: 100
      max-conn-per-route: 100 
      headers: {header1: value1, header2: value2}
    pool:
      min-idle: 5
      max-idle: 8
      max-active: 20
      max-wait: 1000ms
~~~

### 3. 注入ElasticsearchClient

~~~java
@Autowired
private ElasticsearchClient template;
~~~

### 4. 如何使用？

~~~使用
创建index以及及Mapping
    //构建mapping
    
    Map<String, Object> name = new HashMap<>();
    name.put("type", "text");
    name.put("analyzer", "ik_max_word");
    Map<String, Object> age = new HashMap<>();
    age.put("type", "integer");

    Map<String, Object> address = new HashMap<>();
    address.put("type", "text");
    address.put("analyzer", "ik_max_word");
    Map<String, Object> properties = new HashMap<>();
    properties.put("name", name);
    properties.put("age", age);
    properties.put("address", address);

    Map<String, Object> mapping = new HashMap<>();
    mapping.put("properties", properties);
    
    //users为index名称
    CreateIndexRequest request = new CreateIndexRequest("users").mapping(mapping);
    template.opsForIndices().create(request);
    
   //删除索引
          
      DeleteIndexRequest request = new DeleteIndexRequest("users");
      template.opsForIndices().delete(request);
      
   //创建文档
   //用户数据
        
    Map<String, Object> map = new HashMap<>();
    map.put("name", "zing");
    map.put("age", 26);
    map.put("address","global village");

    IndexRequest request = new IndexRequest("users").id("1").source(map);
    template.persist(request);
    
   //根据id查找文档
   
    GetRequest request = new GetRequest("users").id("1");
    Map<String, Object> map = template.get(request);

   //更新文档
   //用户数据

    Map<String, Object> map = new HashMap<>();
    map.put("name", "bobo");
    map.put("age", 28);

    UpdateRequest request = new UpdateRequest("users", "1").doc(map);
    template.update(request);
    
   //删除数据
   
    DeleteRequest request = new DeleteRequest("users").id("1");
    template.delete(request);
    
   //数据检索
   //检索使用ES官方提供的多种QueryBuilder，下面以MultiMatchQueryBuilder为例。
   //fields为需要检索的字段名(如：name，address)，param为查询条件

    public List<Map<String, Object>> search(String index, String param, String...fields) {
    MultiMatchQueryBuilder queryBuilder = new MultiMatchQueryBuilder(param, fields); 
    return template.opsForQuery().multiMatch(index, queryBuilder);
    }
   //分页检索

    public List<Map<String, Object>> search(String index, String param, String...fields) {
    MultiMatchQueryBuilder queryBuilder = new MultiMatchQueryBuilder(param, fields); 
    return template.opsForQuery()
            .from(0)
            .size(10)
            .multiMatch(index, queryBuilder);
    }
   //高亮显示

    public List<Map<String, Object>> search(String index, String param, String...fields) {
    MultiMatchQueryBuilder queryBuilder = new MultiMatchQueryBuilder(param, fields); 
    HighlightBuilder highlightBuilder = HighlightUtils.createHighlightBuilder(HighlightType.UNIFIED, fields);
    return template.opsForQuery()
            .highlight(highlightBuilder)
            .multiMatch(index, queryBuilder);
    }
   //异步操作
  
    public List<Map<String, Object>> search(String index, String param, String...fields) {
    MultiMatchQueryBuilder queryBuilder = new MultiMatchQueryBuilder(param, fields); 
    template.opsForQuery()
            .multiMatch(index, queryBuilder, new ActionListener<SearchResponse>() {
                @Override
                public void onResponse(SearchResponse searchResponse) {
                    for (SearchHit hit : searchResponse.getHits().getHits()) {
                        log.info(hit.getSourceAsString());
                    }
                }

                @Override
                public void onFailure(Exception e) {
                }
	     });
    }

   //使用execute方法操作RestHighLevelClient
   //例如添加一条记录
   
    template.execute((highLevelClient) -> {
    IndexRequest request = new IndexRequest(index).id(id).source(map);
    request.timeout(TimeValue.timeValueNanos(timeout));
    highLevelClient.index(request, RequestOptions.DEFAULT);
    });
~~~